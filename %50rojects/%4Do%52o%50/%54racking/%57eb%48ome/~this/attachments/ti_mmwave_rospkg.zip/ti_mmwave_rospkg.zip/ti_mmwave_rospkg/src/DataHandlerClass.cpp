/*
 * DataHandlerClass.cpp
 *
 * This is the implementation of the DataHandlerClass.h
 * Three threads are spawned when start() is called.
 *  1) readIncomingData() thread
 *  2) sortIncomingData() thread
 *  3) syncedBufferSwap() thread
 *  
 * Together they implement a double-buffered read from the data serial port 
 * which sorts the data into the class's mmwDataPacket struct.
 *
 *
 * Copyright (C) 2017 Texas Instruments Incorporated - http://www.ti.com/ 
 * 
 * 
 *  Redistribution and use in source and binary forms, with or without 
 *  modification, are permitted provided that the following conditions 
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the   
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/


#include <DataHandlerClass.h>
#include <pthread.h>
#include <algorithm>
#include "pcl_ros/point_cloud.h"
#include "sensor_msgs/PointField.h"
#include "sensor_msgs/PointCloud2.h"
#include "sensor_msgs/point_cloud2_iterator.h"
#include "ti_mmwave_rospkg/Track.h"
#include "ti_mmwave_rospkg/Track_list.h"
#include <pcl/io/pcd_io.h>
#include <pcl/point_types.h>
#include <cmath>


DataUARTHandler::DataUARTHandler(ros::NodeHandle* nh) : currentBufp(&pingPongBuffers[0]) , nextBufp(&pingPongBuffers[1]) 
{
    nodeHandle = nh;
    DataUARTHandler_pub = nodeHandle->advertise< sensor_msgs::PointCloud2 >("RScan", 100);
    DataUARTHandler_pub_doppler = nodeHandle->advertise< sensor_msgs::PointCloud2 >("RScan_doppler", 100);
	DataUARTHandler_pub_tracks = nodeHandle->advertise<ti_mmwave_rospkg::Track_list>("tracks", 100);
    maxAllowedElevationAngleDeg = 90; // Use max angle if none specified
    maxAllowedAzimuthAngleDeg = 90; // Use max angle if none specified
}

/*Implementation of setUARTPort*/
void DataUARTHandler::setUARTPort(char* mySerialPort)
{
    dataSerialPort = mySerialPort;
}

/*Implementation of setBaudRate*/
void DataUARTHandler::setBaudRate(int myBaudRate)
{
    dataBaudRate = myBaudRate;
}

/*Implementation of setMaxAllowedElevationAngleDeg*/
void DataUARTHandler::setMaxAllowedElevationAngleDeg(int myMaxAllowedElevationAngleDeg)
{
    maxAllowedElevationAngleDeg = myMaxAllowedElevationAngleDeg;
}

/*Implementation of setMaxAllowedAzimuthAngleDeg*/
void DataUARTHandler::setMaxAllowedAzimuthAngleDeg(int myMaxAllowedAzimuthAngleDeg)
{
    maxAllowedAzimuthAngleDeg = myMaxAllowedAzimuthAngleDeg;
}

/*Implementation of readIncomingData*/
void *DataUARTHandler::readIncomingData(void)
{
    
    int firstPacketReady = 0;
    uint8_t last8Bytes[8] = {0};
    
    /*Open UART Port and error checking*/
    serial::Serial mySerialObject("", dataBaudRate, serial::Timeout::simpleTimeout(100));
    mySerialObject.setPort(dataSerialPort);
    try
    {
        mySerialObject.open();
    } catch (std::exception &e1) {
        ROS_INFO("DataUARTHandler Read Thread: Failed to open Data serial port with error: %s", e1.what());
        ROS_INFO("DataUARTHandler Read Thread: Waiting 20 seconds before trying again...");
        try
        {
            // Wait 20 seconds and try to open serial port again
            ros::Duration(20).sleep();
            mySerialObject.open();
        } catch (std::exception &e2) {
            ROS_ERROR("DataUARTHandler Read Thread: Failed second time to open Data serial port, error: %s", e1.what());
            ROS_ERROR("DataUARTHandler Read Thread: Port could not be opened. Port is \"%s\" and baud rate is %d", dataSerialPort, dataBaudRate);
            pthread_exit(NULL);
        }
    }
    
    if(mySerialObject.isOpen())
        ROS_INFO("DataUARTHandler Read Thread: Port is open");
    else
        ROS_ERROR("DataUARTHandler Read Thread: Port could not be opened");
    
    /*Quick magicWord check to synchronize program with data Stream*/
    while(!isMagicWord(last8Bytes))
    {

        last8Bytes[0] = last8Bytes[1];
        last8Bytes[1] = last8Bytes[2];
        last8Bytes[2] = last8Bytes[3];
        last8Bytes[3] = last8Bytes[4];
        last8Bytes[4] = last8Bytes[5];
        last8Bytes[5] = last8Bytes[6];
        last8Bytes[6] = last8Bytes[7];
        mySerialObject.read(&last8Bytes[7], 1);
        
    }
    
    /*Lock nextBufp before entering main loop*/
    pthread_mutex_lock(&nextBufp_mutex);
    
    while(ros::ok())
    {
        /*Start reading UART data and writing to buffer while also checking for magicWord*/
        last8Bytes[0] = last8Bytes[1];
        last8Bytes[1] = last8Bytes[2];
        last8Bytes[2] = last8Bytes[3];
        last8Bytes[3] = last8Bytes[4];
        last8Bytes[4] = last8Bytes[5];
        last8Bytes[5] = last8Bytes[6];
        last8Bytes[6] = last8Bytes[7];
        mySerialObject.read(&last8Bytes[7], 1);
        
        nextBufp->push_back( last8Bytes[7] );  //push byte onto buffer
        
        //ROS_INFO("DataUARTHandler Read Thread: last8bytes = %02x%02x %02x%02x %02x%02x %02x%02x",  last8Bytes[7], last8Bytes[6], last8Bytes[5], last8Bytes[4], last8Bytes[3], last8Bytes[2], last8Bytes[1], last8Bytes[0]);
        
        /*If a magicWord is found wait for sorting to finish and switch buffers*/
        if( isMagicWord(last8Bytes) )
        {
            //ROS_INFO("Found magic word");
        
            /*Lock countSync Mutex while unlocking nextBufp so that the swap thread can use it*/
            pthread_mutex_lock(&countSync_mutex);
            pthread_mutex_unlock(&nextBufp_mutex);
            
            /*increment countSync*/
            countSync++;
            
            /*If this is the first packet to be found, increment countSync again since Sort thread is not reading data yet*/
            if(firstPacketReady == 0)
            {
                countSync++;
                firstPacketReady = 1;
            }
            
            /*Signal Swap Thread to run if countSync has reached its max value*/
            if(countSync == COUNT_SYNC_MAX)
            {
                pthread_cond_signal(&countSync_max_cv);
            }
            
            /*Wait for the Swap thread to finish swapping pointers and signal us to continue*/
            pthread_cond_wait(&read_go_cv, &countSync_mutex);
            
            /*Unlock countSync so that Swap Thread can use it*/
            pthread_mutex_unlock(&countSync_mutex);
            pthread_mutex_lock(&nextBufp_mutex);
            
            nextBufp->clear();
            memset(last8Bytes, 0, sizeof(last8Bytes));
              
        }
      
    }
    
    
    mySerialObject.close();
    
    pthread_exit(NULL);
}


int DataUARTHandler::isMagicWord(uint8_t last8Bytes[8])
{
    int val = 0, i = 0, j = 0;
    
    for(i = 0; i < 8 ; i++)
    {
    
       if( last8Bytes[i] == magicWord[i])
       {
          j++;
       }
    
    }
    
    if( j == 8)
    {
       val = 1;
    }
    
    return val;  
}

void *DataUARTHandler::syncedBufferSwap(void)
{
    while(ros::ok())
    {
        pthread_mutex_lock(&countSync_mutex);
    
        while(countSync < COUNT_SYNC_MAX)
        {
            pthread_cond_wait(&countSync_max_cv, &countSync_mutex);
            
            pthread_mutex_lock(&currentBufp_mutex);
            pthread_mutex_lock(&nextBufp_mutex);
            
            std::vector<uint8_t>* tempBufp = currentBufp;
        
            this->currentBufp = this->nextBufp;
            
            this->nextBufp = tempBufp;
            
            pthread_mutex_unlock(&currentBufp_mutex);
            pthread_mutex_unlock(&nextBufp_mutex);
            
            countSync = 0;
            
            pthread_cond_signal(&sort_go_cv);
            pthread_cond_signal(&read_go_cv);
            
        }
    
        pthread_mutex_unlock(&countSync_mutex);

    }

    pthread_exit(NULL);
    
}

void *DataUARTHandler::sortIncomingData( void )
{
    MmwDemo_Output_TLV_Types tlvType = MMWDEMO_OUTPUT_MSG_NULL;
    uint32_t tlvLen = 0;
    uint32_t headerSize;
    unsigned int currentDatap = 0;
    SorterState sorterState = READ_HEADER;
    int i = 0, tlvCount = 0, offset = 0;
    float maxElevationAngleRatioSquared;
    float maxAzimuthAngleRatio;
    
    boost::shared_ptr<pcl::PointCloud<pcl::PointXYZI>> RScan(new pcl::PointCloud<pcl::PointXYZI>);
    boost::shared_ptr<pcl::PointCloud<pcl::PointXYZI>> RScan_doppler(new pcl::PointCloud<pcl::PointXYZI>);

	ti_mmwave_rospkg::Track_list track_list;
	ti_mmwave_rospkg::Track track;

    //wait for first packet to arrive
    pthread_mutex_lock(&countSync_mutex);
    pthread_cond_wait(&sort_go_cv, &countSync_mutex);
    pthread_mutex_unlock(&countSync_mutex);
    
    pthread_mutex_lock(&currentBufp_mutex);
    
    while(ros::ok())
    {
        
        switch(sorterState)
        {
            
        case READ_HEADER:

            ROS_INFO("data in buffer %d bytes", currentBufp->size());
		
			static uint32_t version;
            memcpy( &version, &currentBufp->at(currentDatap), sizeof(version));
            currentDatap += ( sizeof(version) );
            
			static uint32_t platform;
            memcpy( &platform, &currentBufp->at(currentDatap), sizeof(platform));
            currentDatap += ( sizeof(platform) );
			
			static uint32_t timestamp;
            memcpy( &timestamp, &currentBufp->at(currentDatap), sizeof(timestamp));
            currentDatap += ( sizeof(timestamp) );
			
			static uint32_t packetLength;
            memcpy( &packetLength, &currentBufp->at(currentDatap), sizeof(packetLength));
            currentDatap += ( sizeof(packetLength) );

			if(currentBufp->size() != packetLength)
			{
				sorterState = SWAP_BUFFERS;
				break;
			}
			
			static uint32_t frameNumber;
            memcpy( &frameNumber, &currentBufp->at(currentDatap), sizeof(frameNumber));
            currentDatap += ( sizeof(frameNumber) );
			
			static uint32_t subframeNumber;
            memcpy( &subframeNumber, &currentBufp->at(currentDatap), sizeof(subframeNumber));
            currentDatap += ( sizeof(subframeNumber) );
			
			static uint32_t chirpMargin;
            memcpy( &chirpMargin, &currentBufp->at(currentDatap), sizeof(chirpMargin));
            currentDatap += ( sizeof(chirpMargin) );
			
			static uint32_t frameMargin;
            memcpy( &frameMargin, &currentBufp->at(currentDatap), sizeof(frameMargin));
            currentDatap += ( sizeof(frameMargin) );
			
			static uint32_t uartSentTime;
            memcpy( &uartSentTime, &currentBufp->at(currentDatap), sizeof(uartSentTime));
            currentDatap += ( sizeof(uartSentTime) );
			
			static uint32_t trackProcessTime;
            memcpy( &trackProcessTime, &currentBufp->at(currentDatap), sizeof(trackProcessTime));
            currentDatap += ( sizeof(trackProcessTime) );
				 
			static uint16_t numTLVs;
            memcpy( &numTLVs, &currentBufp->at(currentDatap), sizeof(numTLVs));
            currentDatap += ( sizeof(numTLVs) );
            
            static uint16_t checksum;
            memcpy( &checksum, &currentBufp->at(currentDatap), sizeof(checksum));
            currentDatap += ( sizeof(checksum) );

			ROS_INFO("version = %d, platform = %d, timestamp = %d, packetLength = %d, frameNumber = %d, subframeNumber = %d, chirpMargin = %d, frameMargin = %d, uartSentTime = %d, trackProcessTime = %d, numTLVs = %d, checksum = %d", version, platform, timestamp, packetLength, frameNumber, subframeNumber, chirpMargin, frameMargin, uartSentTime, trackProcessTime, numTLVs, checksum);
			
            sorterState = CHECK_TLV_TYPE;
            
            break;
            
        case READ_OBJ_STRUCT:
            
            i = 0;
            offset = 0;
			
			
			
			mmwData.numObjOut = tlvLen / 68 /* one track length */;
            
            ROS_INFO("tlvLen = %d, numObjOut = %d", tlvLen, mmwData.numObjOut);

			track_list.header.seq = 0;
			track_list.header.stamp = ros::Time::now();
			track_list.header.frame_id = "base_radar_link";
			track_list.size = mmwData.numObjOut;
			track_list.tracks.clear();
			
            RScan->header.seq = 0;
            //RScan->header.stamp = (uint32_t) mmwData.header.timeCpuCycles;
            RScan->header.stamp = ((pcl::uint64_t)ros::Time::now().sec) * 1000ULL * 1000ULL + ((pcl::uint64_t)ros::Time::now().nsec) / 1000ULL;
            RScan->header.frame_id = "base_radar_link";
            RScan->height = 1;
            RScan->width = mmwData.numObjOut;
            RScan->is_dense = 1;
            RScan->points.resize(RScan->width * RScan->height);
 
            while( i < mmwData.numObjOut )
            {
				static uint32_t tid;
                memcpy( &tid, &currentBufp->at(currentDatap), sizeof(tid));
                currentDatap += ( sizeof(tid) );
				track.id = tid;
                
                static float posX;
                memcpy( &posX, &currentBufp->at(currentDatap), sizeof(posX));
                currentDatap += ( sizeof(posX) );
				
                
                static float posY;
                memcpy( &posY, &currentBufp->at(currentDatap), sizeof(posY));
                currentDatap += ( sizeof(posY) );
				
				
				static float velX;
                memcpy( &velX, &currentBufp->at(currentDatap), sizeof(velX));
                currentDatap += ( sizeof(velX) );
				
				
				static float velY;
                memcpy( &velY, &currentBufp->at(currentDatap), sizeof(velY));
                currentDatap += ( sizeof(velY) );
				
				
				static float accX;
                memcpy( &accX, &currentBufp->at(currentDatap), sizeof(accX));
                currentDatap += ( sizeof(accX) );

				
				static float accY;
                memcpy( &accY, &currentBufp->at(currentDatap), sizeof(accY));
                currentDatap += ( sizeof(accY) );

				
				static float EC_1;
                memcpy( &EC_1, &currentBufp->at(currentDatap), sizeof(EC_1));
                currentDatap += ( sizeof(EC_1) );
				track.ec[0] = EC_1;
				
				static float EC_2;
                memcpy( &EC_2, &currentBufp->at(currentDatap), sizeof(EC_2));
                currentDatap += ( sizeof(EC_2) );
				track.ec[1] = EC_2;
				
				static float EC_3;
                memcpy( &EC_3, &currentBufp->at(currentDatap), sizeof(EC_3));
                currentDatap += ( sizeof(EC_3) );
				track.ec[2] = EC_3;
				
				static float EC_4;
                memcpy( &EC_4, &currentBufp->at(currentDatap), sizeof(EC_4));
                currentDatap += ( sizeof(EC_4) );
				track.ec[3] = EC_4;
				
				static float EC_5;
                memcpy( &EC_5, &currentBufp->at(currentDatap), sizeof(EC_5));
                currentDatap += ( sizeof(EC_5) );
				track.ec[4] = EC_5;
				
				static float EC_6;
                memcpy( &EC_6, &currentBufp->at(currentDatap), sizeof(EC_6));
                currentDatap += ( sizeof(EC_6) );
				track.ec[5] = EC_6;
				
				static float EC_7;
                memcpy( &EC_7, &currentBufp->at(currentDatap), sizeof(EC_7));
                currentDatap += ( sizeof(EC_7) );
				track.ec[6] = EC_7;
				
				static float EC_8;
                memcpy( &EC_8, &currentBufp->at(currentDatap), sizeof(EC_8));
                currentDatap += ( sizeof(EC_8) );
				track.ec[7] = EC_8;
				
				static float EC_9;
                memcpy( &EC_9, &currentBufp->at(currentDatap), sizeof(EC_9));
                currentDatap += ( sizeof(EC_9) );
				track.ec[8] = EC_9;
				
				static float G;
                memcpy( &G, &currentBufp->at(currentDatap), sizeof(G));
                currentDatap += ( sizeof(G) );
				track.gain = G;
                
				track.position_x = posY;
				track.position_y = -posX;
				track.velocity_x = velY;
				track.velocity_y = -velX;
				track.acceleration_x = accY;
				track.acceleration_y = -accX;
				track_list.tracks.push_back(track);
				
				ROS_INFO("tid = %d, posX = %f, posY = %f, velX = %f, velY = %f, accX = %f, accY = %f, G = %f", tid, posX, posY, velX, velY, accX, accY, G);
				
                RScan->points[i].x = posY;   // ROS standard coordinate system X-axis is forward which is the mmWave sensor Y-axis
                RScan->points[i].y = -posX;  // ROS standard coordinate system Y-axis is left which is the mmWave sensor -(X-axis)
                RScan->points[i].z = 0;
                RScan->points[i].intensity = 0;

                i++;
            }
             
            DataUARTHandler_pub.publish(RScan);
			DataUARTHandler_pub_tracks.publish(track_list);
            
            sorterState = CHECK_TLV_TYPE;
            
            break;
        
        case CHECK_TLV_TYPE:
        
            ROS_INFO("tlvCount = %d", tlvCount);
        
            if(tlvCount++ >= numTLVs)
            {
                //ROS_INFO("DataUARTHandler Sort Thread : CHECK_TLV_TYPE state says tlvCount max was reached, going to switch buffer state");
                sorterState = SWAP_BUFFERS;
            }
            else
            {
               //get tlvType (32 bits) & remove from queue
                memcpy( &tlvType, &currentBufp->at(currentDatap), sizeof(tlvType));
                currentDatap += ( sizeof(tlvType) );
                
                //ROS_INFO("DataUARTHandler Sort Thread : sizeof(tlvType) = %d", sizeof(tlvType));
            
                //get tlvLen (32 bits) & remove from queue
                memcpy( &tlvLen, &currentBufp->at(currentDatap), sizeof(tlvLen));
                currentDatap += ( sizeof(tlvLen) );
                
                //ROS_INFO("DataUARTHandler Sort Thread : sizeof(tlvLen) = %d", sizeof(tlvLen));
                
                //ROS_INFO("DataUARTHandler Sort Thread : tlvType = %d, tlvLen = %d", (int) tlvType, tlvLen);
            
                switch(tlvType)
                {
                
				case 6: // point cloud
					currentDatap += (tlvLen -  (sizeof(tlvLen) + sizeof(tlvType)));
					sorterState = CHECK_TLV_TYPE;
					break;
				
				case 7: // target list
					sorterState = READ_OBJ_STRUCT;
					break;
				
				case 8: // target index (target detection association)
					currentDatap += (tlvLen -  (sizeof(tlvLen) + sizeof(tlvType)));
					sorterState = CHECK_TLV_TYPE;
					break;
					
                default:
					ROS_INFO("TLV type unknown: %d", tlvType);
					sorterState = SWAP_BUFFERS;
					break;
                }
            }
            
        break;
            
		case SWAP_BUFFERS:
       
            pthread_mutex_lock(&countSync_mutex);
            pthread_mutex_unlock(&currentBufp_mutex);
                            
            countSync++;
                
            if(countSync == COUNT_SYNC_MAX)
            {
                pthread_cond_signal(&countSync_max_cv);
            }
                
            pthread_cond_wait(&sort_go_cv, &countSync_mutex);
                
            pthread_mutex_unlock(&countSync_mutex);
            pthread_mutex_lock(&currentBufp_mutex);
                
            currentDatap = 0;
            tlvCount = 0;
                
            sorterState = READ_HEADER;
            
            break;
                
            
        default: break;
        }
    }
    
    
    pthread_exit(NULL);
}

void DataUARTHandler::start(void)
{
    
    pthread_t uartThread, sorterThread, swapThread;
    
    int  iret1, iret2, iret3;
    
    pthread_mutex_init(&countSync_mutex, NULL);
    pthread_mutex_init(&nextBufp_mutex, NULL);
    pthread_mutex_init(&currentBufp_mutex, NULL);
    pthread_cond_init(&countSync_max_cv, NULL);
    pthread_cond_init(&read_go_cv, NULL);
    pthread_cond_init(&sort_go_cv, NULL);
    
    countSync = 0;
    
    /* Create independent threads each of which will execute function */
    iret1 = pthread_create( &uartThread, NULL, this->readIncomingData_helper, this);
    if(iret1)
    {
     ROS_INFO("Error - pthread_create() return code: %d\n",iret1);
     ros::shutdown();
    }
    
    iret2 = pthread_create( &sorterThread, NULL, this->sortIncomingData_helper, this);
    if(iret2)
    {
        ROS_INFO("Error - pthread_create() return code: %d\n",iret1);
        ros::shutdown();
    }
    
    iret3 = pthread_create( &swapThread, NULL, this->syncedBufferSwap_helper, this);
    if(iret3)
    {
        ROS_INFO("Error - pthread_create() return code: %d\n",iret1);
        ros::shutdown();
    }
    
    ros::spin();

    pthread_join(iret1, NULL);
    ROS_INFO("DataUARTHandler Read Thread joined");
    pthread_join(iret2, NULL);
    ROS_INFO("DataUARTHandler Sort Thread joined");
    pthread_join(iret3, NULL);
    ROS_INFO("DataUARTHandler Swap Thread joined");
    
    pthread_mutex_destroy(&countSync_mutex);
    pthread_mutex_destroy(&nextBufp_mutex);
    pthread_mutex_destroy(&currentBufp_mutex);
    pthread_cond_destroy(&countSync_max_cv);
    pthread_cond_destroy(&read_go_cv);
    pthread_cond_destroy(&sort_go_cv);
    
    
}

void* DataUARTHandler::readIncomingData_helper(void *context)
{  
    return (static_cast<DataUARTHandler*>(context)->readIncomingData());
}

void* DataUARTHandler::sortIncomingData_helper(void *context)
{  
    return (static_cast<DataUARTHandler*>(context)->sortIncomingData());
}

void* DataUARTHandler::syncedBufferSwap_helper(void *context)
{  
    return (static_cast<DataUARTHandler*>(context)->syncedBufferSwap());
}
