#include <Cross_traffic.h>

Cross_traffic::Cross_traffic(float range_rate_min_threshold, float intensity_min_threshold, float position_distance_threshold, float speed_distance_threshold, float radius, float simulation_time)
{
	this->range_rate_min_threshold = range_rate_min_threshold;
	this->intensity_min_threshold = intensity_min_threshold;

	this->position_distance_threshold = position_distance_threshold;
	this->speed_distance_threshold = speed_distance_threshold;

	this->radius = radius;
	this->simulation_time = simulation_time;
}

Cross_traffic::~Cross_traffic()
{
}

void Cross_traffic::process_detection(float range, float range_rate, float angle, float intensity)
{
	float position[2];
	float speed[2];

	if (range_rate > range_rate_min_threshold)
	{
		return;
	}

	if (intensity < intensity_min_threshold)
	{
		return;
	}

	position[0] = range * cosf(angle);
	position[1] = range * sinf(angle);

	speed[0] = range_rate * cosf(angle);
	speed[1] = range_rate * sinf(angle);

	float min_distance = INFINITY;
	Track* min_distance_track = 0;

	for (std::forward_list<Track>::iterator track = tracks.begin(); track != tracks.end(); track++)
	{
		float position_distance = track->get_position_distance(position);
		float speed_distance = track->get_speed_distance(speed);

		if (position_distance < position_distance_threshold && speed_distance < speed_distance_threshold)
		{
			if (position_distance + speed_distance < min_distance)
			{
				min_distance = position_distance + speed_distance;
				min_distance_track = &(*track);
			}
		}
	}

	if (min_distance_track != 0)
	{
		min_distance_track->add_detection(position, speed);
	}
	else
	{
		tracks.emplace_front(position, speed);
	}
}

bool sealed_track(Track& track) { return track.is_sealed(); }

void Cross_traffic::end_scan()
{
	for (std::forward_list<Track>::iterator track = tracks.begin(); track != tracks.end(); track++)
	{
		track->update();
	}

	tracks.remove_if(sealed_track);
}



bool Cross_traffic::check_expected_collision()
{
	for (std::forward_list<Track>::iterator track = tracks.begin(); track != tracks.end(); track++)
	{
		if (track->is_valid() == true)
		{
			if (check_expected_collision_track(track) == true)
			{
				return true;
			}
		}
	}
	return false;
}

bool Cross_traffic::check_expected_collision_track(std::forward_list<Track>::iterator track)
{
	float start_position[2];
	float end_position[2];
	float speed[2];
	
	track->get_position(start_position);
	track->get_speed(speed);

	end_position[0] = start_position[0] + speed[0] * simulation_time;
	end_position[1] = start_position[1] + speed[1] * simulation_time;

	float distance = sqrtf(start_position[0] * start_position[0] + start_position[1] * start_position[1]);
	if (distance < radius)	// if start point is inside the circle
	{
		return true;
	}

	distance = sqrtf(end_position[0] * end_position[0] + end_position[1] * end_position[1]);
	if (distance < radius)	// if the end point is inside the circle
	{
		return true;
	}

	// solve for t the following equation (line intersection with a circle with center (0,0)):-
	// [x1 ^ 2 + y1 ^ 2 - R ^ 2] + 2 * [x1 * (x2 - x1) + y1 * (y2 - y1)] * t + [(x2 - x1) ^ 2 + (y2 - y1) ^ 2] * t ^ 2 = 0
	// where:
	// x1 = start_position[0]
	// y1 = start_position[1]
	// x2 = end_position[0]
	// y2 = end_position[1]
	// R = radius
	// t == 0 -> start_position
	// t == 1 -> end_position

	// factors calculation as: a * t ^ 2 + b * t + c = 0
	float a = (end_position[0] - start_position[0]) * (end_position[0] - start_position[0]) + (end_position[1] - start_position[1]) * (end_position[1] - start_position[1]);
	float b = 2 * (start_position[0] * (end_position[0] - start_position[0]) + start_position[1] * (end_position[1] - start_position[1]));
	float c = start_position[0] * start_position[0] + start_position[1] * start_position[1] - radius * radius;

	float discriminant = b * b - 4 * a * c;
	if (discriminant <= 0)	// no intersection or tangent
	{

		return false;
	}

	// the line or its extension intersects with the circle

	// solutions calculation
	float sqrt_discriminant = sqrtf(discriminant);
	float t1 = (-b + sqrt_discriminant) / (2 * a);
	float t2 = (-b - sqrt_discriminant) / (2 * a);

	if ((0 < t1 && t1 < 1) || (0 < t2 && t2 < 1))	// if either solution is between start_position and end_position
	{
		return true;
	}

	// only the extension of the line intersects with the circle

	return false;
}

std::forward_list<Track> Cross_traffic::get_track_list()
{
	return tracks;
}