#include "ros/ros.h"
#include <std_msgs/Bool.h>
#include "ti_mmwave_rospkg/Track.h"
#include "ti_mmwave_rospkg/Track_list.h"
#include <math.h>

ros::Publisher flag_publisher;

float simulation_time = 5;
float radius = 1;
float length = 3;

bool check_expected_collision_track_with_line(ti_mmwave_rospkg::Track track)
{
	float start_position[2];
	float end_position[2];
	float speed[2];
	
	float line_start_position[2];
	float line_end_position[2];
	
	start_position[0] = track.position_x;
	start_position[1] = track.position_y;
	speed[0] = track.velocity_x;
	speed[1] = track.velocity_y;

	end_position[0] = start_position[0] + speed[0] * simulation_time;
	end_position[1] = start_position[1] + speed[1] * simulation_time;
	
	// a line representing robot expected movement
	line_start_position[0] = 0;
	line_start_position[1] = 0;
	line_end_position[0] = length;
	line_end_position[1] = 0;
	
	// calcualte the parameters
	// t = ((x1 - x3) * (y3 - y4) - (y1 - y3) * (x3 - x4)) / ((x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4))
	// u = - ((x1 - x2) * (y1 - y3) - (y1 - y2) * (x1 - x3)) / ((x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4))
	// where:
	// x1 = start_position[0]
	// y1 = start_position[1]
	// x2 = end_position[0]
	// y2 = end_position[1]
	// x3 = line_start_position[0]
	// y3 = line_start_position[1]
	// x4 = line_end_position[0]
	// y4 = line_end_position[1]
	// t == 0 -> start_position
	// t == 1 -> end_position
	// u == 0 -> line_start_position
	// u == 1 -> line_end_position
	
	float denominator = (start_position[0] - end_position[0]) * (line_start_position[1] - line_end_position[1]) - (start_position[1] - end_position[1]) * (line_start_position[0] - line_end_position[0]);
	ROS_INFO("denominator = %f", denominator);
	// lines are parallel
	if (denominator == 0)
	{
		return false;
	}

	float t = ((start_position[0] - line_start_position[0]) * (line_start_position[1] - line_end_position[1]) - (start_position[1] - line_start_position[1]) * (line_start_position[0] - line_end_position[0])) / denominator;
	float u = - ((start_position[0] - end_position[0]) * (start_position[1] - line_start_position[1]) - (start_position[1] - end_position[1]) * (start_position[0] - line_start_position[0])) / denominator;
	ROS_INFO("t = %f, u = %f", t, u);	

	// if the intersection point is within both lines ends
	if (t >= 0 && t <= 1 && u >= 0 && u <= 1)
	{
		return true;
	}
	
	// no intersection
	return false;
}

bool check_expected_collision_track_with_circle(ti_mmwave_rospkg::Track track)
{
	float start_position[2];
	float end_position[2];
	float speed[2];
	
	start_position[0] = track.position_x;
	start_position[1] = track.position_y;
	speed[0] = track.velocity_x;
	speed[1] = track.velocity_y;

	end_position[0] = start_position[0] + speed[0] * simulation_time;
	end_position[1] = start_position[1] + speed[1] * simulation_time;

	float distance = sqrtf(start_position[0] * start_position[0] + start_position[1] * start_position[1]);
	if (distance < radius)	// if start point is inside the circle
	{
		return true;
	}

	distance = sqrtf(end_position[0] * end_position[0] + end_position[1] * end_position[1]);
	if (distance < radius)	// if the end point is inside the circle
	{
		return true;
	}

	// solve for t the following equation (line intersection with a circle with center (0,0)):-
	// [x1 ^ 2 + y1 ^ 2 - R ^ 2] + 2 * [x1 * (x2 - x1) + y1 * (y2 - y1)] * t + [(x2 - x1) ^ 2 + (y2 - y1) ^ 2] * t ^ 2 = 0
	// where:
	// x1 = start_position[0]
	// y1 = start_position[1]
	// x2 = end_position[0]
	// y2 = end_position[1]
	// R = radius
	// t == 0 -> start_position
	// t == 1 -> end_position

	// factors calculation as: a * t ^ 2 + b * t + c = 0
	float a = (end_position[0] - start_position[0]) * (end_position[0] - start_position[0]) + (end_position[1] - start_position[1]) * (end_position[1] - start_position[1]);
	float b = 2 * (start_position[0] * (end_position[0] - start_position[0]) + start_position[1] * (end_position[1] - start_position[1]));
	float c = start_position[0] * start_position[0] + start_position[1] * start_position[1] - radius * radius;

	float discriminant = b * b - 4 * a * c;
	if (discriminant <= 0)	// no intersection or tangent
	{
		return false;
	}

	// the line or its extension intersects with the circle

	// solutions calculation
	float sqrt_discriminant = sqrtf(discriminant);
	float t1 = (-b + sqrt_discriminant) / (2 * a);
	float t2 = (-b - sqrt_discriminant) / (2 * a);

	if ((0 < t1 && t1 < 1) || (0 < t2 && t2 < 1))	// if either solution is between start_position and end_position
	{
		return true;
	}

	// only the extension of the line intersects with the circle

	return false;
}

bool check_expected_collision(const ti_mmwave_rospkg::Track_listConstPtr& track_list)
{
	for (int track_number = 0; track_number < track_list->size; track_number++)
	{
		if (check_expected_collision_track_with_circle(track_list->tracks[track_number]) == true)
		{
			return true;
		}
		else if (check_expected_collision_track_with_line(track_list->tracks[track_number]) == true)
		{
			return true;
		}		
	}
	return false;
}

void scan_Callback(const ti_mmwave_rospkg::Track_listConstPtr& track_list)
{
	std_msgs::Bool flag;
	flag.data = check_expected_collision(track_list);

	ROS_INFO("flag = %d", flag.data);

	flag_publisher.publish(flag);
}

int main(int argc, char **argv)
{
	ros::init(argc, argv, "cross_traffic");

	ros::NodeHandle node;

	flag_publisher = node.advertise<std_msgs::Bool>("cross_traffic_flag", 10);

	ros::Subscriber scan_subscriber = node.subscribe("/mmWaveDataHdl/tracks", 10, scan_Callback);

	ros::spin();

	return 0;
}
