#include <iostream>
#include <math.h>
#include "Track.h"
#include "Cross_traffic.h"

using namespace std;

void main()
{
	float e = 1e-5;

	float p_test[2] = { 0, 0 };
	float v_test[2] = { 0, 0 };

	float p_d_test = 0;
	float v_d_test = 0;

	float p1[2] = { 1.1, 2.3 };
	float v1[2] = { 3.4, 4.6 };

	float p2[2] = { 4.2, -2.7 };
	float v2[2] = { -1.2, 9.4 };

	float p3[2] = { 1.6, 0.7};
	float v3[2] = { 6.1, -5.7 };

	Track track_1(p1, v1);

	track_1.get_position(p_test);
	track_1.get_speed(v_test);

	if (fabsf(p_test[0] - 1.1f) < e && fabsf(p_test[1] - 2.3f) < e && fabsf(v_test[0] - 3.4f) < e && fabsf(v_test[1] - 4.6f) < e)
	{
		cout << "test 1 success" << endl;
	}
	else
	{
		cout << "test 1 failed" << endl;
	}

	p_d_test = track_1.get_position_distance(p2);
	v_d_test = track_1.get_speed_distance(v2);

	if (fabsf(p_d_test - 5.883026f) < e && fabsf(v_d_test - 6.648308f) < e)
	{
		cout << "test 2 success" << endl;
	}
	else
	{
		cout << "test 2 failed" << endl;
	}

	track_1.add_detection(p2, v2);
	track_1.update();
	track_1.get_position(p_test);
	track_1.get_speed(v_test);

	if (fabsf(p_test[0] - 4.2f) < e && fabsf(p_test[1] - -2.7f) < e && fabsf(v_test[0] - -1.2f) < e && fabsf(v_test[1] - 9.4f) < e)
	{
		cout << "test 3 success" << endl;
	}
	else
	{
		cout << "test 3 failed" << endl;
	}

	if (track_1.is_sealed() == true) cout << "test 4 failed" << endl;
	track_1.update();
	if (track_1.is_sealed() == true) cout << "test 4 failed" << endl;
	track_1.update();
	if (track_1.is_sealed() == true) cout << "test 4 failed" << endl;
	track_1.update();
	if (track_1.is_sealed() == true) cout << "test 4 failed" << endl;
	track_1.update();
	if (track_1.is_sealed() == true) cout << "test 4 failed" << endl;
	else cout << "test 4 success" << endl;

	track_1.update();
	if (track_1.is_sealed() == true)
	{
		cout << "test 5 success" << endl;
	}
	else
	{
		cout << "test 5 failed" << endl;
	}

	Track track_2;

	for (int i = 0; i < 30; i++)
	{
		if (track_2.is_valid() == true) cout << "test 6 failed" << endl;
		track_2.add_detection(p1, v1);
		track_2.update();
	}

	if (track_2.is_valid() == true)
	{
		cout << "test 6 success" << endl;
	}
	else
	{
		cout << "test 6 failed" << endl;
	}

	Track track_3;

	for (int i = 0; i < 15; i++)
	{
		if (track_3.is_valid() == true) cout << "test 7 failed" << endl;
		track_3.add_detection(p1, v1);
		track_3.update();
	}
	
	track_3.update();
	track_3.update();
	track_3.update();

	for (int i = 0; i < 15; i++)
	{
		if (track_3.is_valid() == true) cout << "test 7 failed" << endl;
		track_3.add_detection(p1, v1);
		track_3.update();
	}

	if (track_3.is_valid() == true)
	{
		cout << "test 7 success" << endl;
	}
	else
	{
		cout << "test 7 failed" << endl;
	}

	Track track_4;

	track_4.add_detection(p1, v1);
	track_4.add_detection(p2, v2);
	track_4.add_detection(p3, v3);

	track_4.update();

	track_4.get_position(p_test);
	track_4.get_speed(v_test);

	if (fabsf(p_test[0] - 2.3f) < e && fabsf(p_test[1] - 0.1f) < e && fabsf(v_test[0] - 2.766666f) < e && fabsf(v_test[1] - 2.766666f) < e)
	{
		cout << "test 8 success" << endl;
	}
	else
	{
		cout << "test 8 failed" << endl;
	}

	cout << endl << "press enter to continue...";
	cin.get();
}