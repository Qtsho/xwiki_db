#pragma once

#include<math.h>

class Track
{
private:
	float position[2];
	float speed[2];
	
	float sum_of_new_detections_position[2];
	float sum_of_new_detections_speed[2];
	unsigned int number_of_new_detections;
	
	unsigned int missed_updates;
	bool sealed;
	const unsigned int sealing_threshold = 5;

	unsigned int number_of_updates;
	bool valid;
	const unsigned int validating_threshold = 30;

public:
	Track();
	Track(float position[2], float speed[2]);
	~Track();

	void add_detection(float position[2], float speed[2]);
	
	float get_position_distance(float position[2]);
	float get_speed_distance(float speed[2]);
	
	void update();

	bool is_sealed();

	bool is_valid();

	void get_position(float position[2]);
	void get_speed(float speed[2]);
};

