#pragma once

#include "Track.h"
#include <forward_list>

class Cross_traffic
{
private:
	float range_rate_min_threshold;
	float intensity_min_threshold;

	float position_distance_threshold;
	float speed_distance_threshold;

	float radius;
	float simulation_time;

	std::forward_list<Track> tracks;

	bool check_expected_collision_track(std::forward_list<Track>::iterator track);

public:
	Cross_traffic(float range_rate_min_threshold, float intensity_min_threshold, float position_distance_threshold, float speed_distance_threshold, float radius, float simulation_time);
	~Cross_traffic();

	void process_detection(float range, float range_rate, float angle, float intensity);

	void end_scan();

	bool check_expected_collision();

	std::forward_list<Track> get_track_list();
};

