#include <Track.h>

Track::Track()
{
	position[0] = 0;
	position[1] = 0;
	speed[0] = 0;
	speed[1] = 0;

	sum_of_new_detections_position[0] = 0;
	sum_of_new_detections_position[1] = 0;
	sum_of_new_detections_speed[0] = 0;
	sum_of_new_detections_speed[1] = 0;
	number_of_new_detections = 0;

	missed_updates = 0;
	sealed = false;

	number_of_updates = 0;
	valid = false;
}

Track::Track(float position[2], float speed[2])
{
	this->position[0] = position[0];
	this->position[1] = position[1];
	this->speed[0] = speed[0];
	this->speed[1] = speed[1];

	sum_of_new_detections_position[0] = 0;
	sum_of_new_detections_position[1] = 0;
	sum_of_new_detections_speed[0] = 0;
	sum_of_new_detections_speed[1] = 0;
	number_of_new_detections = 0;

	missed_updates = 0;
	sealed = false;

	number_of_updates = 0;
	valid = false;
}

Track::~Track()
{
}

void Track::add_detection(float position[2], float speed[2])
{
	number_of_new_detections++;
	sum_of_new_detections_position[0] += position[0];
	sum_of_new_detections_position[1] += position[1];
	sum_of_new_detections_speed[0] += speed[0];
	sum_of_new_detections_speed[1] += speed[1];
}

float Track::get_position_distance(float position[2])
{
	float distance_components[2];
	distance_components[0] = this->position[0] - position[0];
	distance_components[1] = this->position[1] - position[1];

	float distance_euclidean = sqrtf(distance_components[0] * distance_components[0] + distance_components[1] * distance_components[1]);
	return distance_euclidean;
}

float Track::get_speed_distance(float speed[2])
{
	float distance_components[2];
	distance_components[0] = this->speed[0] - speed[0];
	distance_components[1] = this->speed[1] - speed[1];

	float distance_euclidean = sqrtf(distance_components[0] * distance_components[0] + distance_components[1] * distance_components[1]);
	return distance_euclidean;
}

void Track::update()
{
	if (number_of_new_detections == 0)
	{
		missed_updates++;
		if (missed_updates >= sealing_threshold)
		{
			sealed = true;
		}

		return;
	}

	missed_updates = 0;

	number_of_updates++;
	if (number_of_updates >= validating_threshold)
	{
		valid = true;
	}

	position[0] = sum_of_new_detections_position[0] / number_of_new_detections;
	position[1] = sum_of_new_detections_position[1] / number_of_new_detections;
	speed[0] = sum_of_new_detections_speed[0] / number_of_new_detections;
	speed[1] = sum_of_new_detections_speed[1] / number_of_new_detections;

	sum_of_new_detections_position[0] = 0;
	sum_of_new_detections_position[1] = 0;
	sum_of_new_detections_speed[0] = 0;
	sum_of_new_detections_speed[1] = 0;
	number_of_new_detections = 0;
}

bool Track::is_sealed()
{
	return sealed;
}

bool Track::is_valid()
{
	return valid;
}

void Track::get_position(float position[2])
{
	position[0] = this->position[0];
	position[1] = this->position[1];
}

void Track::get_speed(float speed[2])
{
	speed[0] = this->speed[0];
	speed[1] = this->speed[1];
}
